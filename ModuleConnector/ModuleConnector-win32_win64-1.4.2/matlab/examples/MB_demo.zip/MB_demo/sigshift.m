function[y,m]=sigshift(x,n,n0)
m=n-n0;
y(m)=x(n);
