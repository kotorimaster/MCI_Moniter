clear;
load('C:/Users/zxy/Desktop/hear/movepuredata.mat')
data=PureData;
br_s2=0;
hr_s2=0;
t=0;
br_s2,hr_s2,t=respiration_multi2 (data);