% picdata=rand(1024,197);
result=localMaximum(rand(1024,197),[10 80]);